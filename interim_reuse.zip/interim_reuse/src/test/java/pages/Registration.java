package pages;

import java.time.Duration;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.CommonMethods;

public class Registration extends CommonMethods {
    protected WebDriverWait wait;
    Logger log = Logger.getLogger(Registration.class);

    @FindBy(xpath="//input[@type=\"radio\"]")
    private WebElement radio;

    @FindBy(id = "FirstName")
    private WebElement fn;

    @FindBy(id = "LastName")
    private WebElement ln;

    @FindBy(id = "Email")
    private WebElement email;

    @FindBy(id = "Company")
    private WebElement com;

    @FindBy(id = "Password")
    private WebElement pass;

    @FindBy(id = "ConfirmPassword")
    private WebElement confirm;
    
    @FindBy(id = "register-button")
    private WebElement register;

    public Registration(WebDriver dr) {
        this.dr = dr;
        this.wait = new WebDriverWait(dr, Duration.ofSeconds(10));
        PageFactory.initElements(dr, this);
        PropertyConfigurator.configure("src\\test\\resources\\log4j.properties");
    }

    public void loginUser(String first, String last, String emailid, String company,String pwd) {
        log.info("Attempting registration for user: ");
        radio.click();
        fn.sendKeys(first);
        ln.sendKeys(last);
        email.sendKeys(emailid);
        com.sendKeys(company);
        pass.sendKeys(pwd);
        confirm.sendKeys(pwd);
        wait.until(ExpectedConditions.elementToBeClickable(register));
        register.click();
    }
}