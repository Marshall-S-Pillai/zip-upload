package tests;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.Assert;
import org.testng.annotations.*;

import pages.Homepage;
import pages.Login;
import pages.Registration;
import pages.Testcase;
import utilities.CommonMethods;
import utilities.configreader;

public class TestingClass extends CommonMethods {

    configreader config = new configreader();
    Logger log = Logger.getLogger(TestingClass.class);
    Homepage ho;
    Login login;
    Registration reg;
    Testcase test;

    @BeforeClass
    @Parameters("BROWSER")
    public void setUp(String browser) {
        PropertyConfigurator.configure("src\\test\\resources\\log4j.properties");
        System.out.println("Launching browser: " + browser);
        launchBrowser(browser);
        ho = new Homepage(dr);
        reg = new Registration(dr);
        login = new Login(dr);
        test = new Testcase(dr);
    }
    
    @Test(priority = 1)
    public void home() {
    	ho.home();
    }
    
    @Test(priority = 2)
    public void register() {
    	String firstname=config.getProperty("first");
    	String lastname=config.getProperty("last");
    	String email=config.getProperty("email");
    	String company=config.getProperty("company");
    	String pass=config.getProperty("pass");
    	String confirm=config.getProperty("confirm");
    	reg.loginUser(firstname, lastname, email, company, pass);
    }

    @Test(priority = 3)
    public void login() {
        String user = "iammarshallhere@gmail.com";
        String pass = "Mars@9087";
        String expectedText = "My account";
        boolean isLoggedIn = login.loginUser(user, pass, expectedText);
        System.out.println("Login Successfully");
        Assert.assertTrue(isLoggedIn, "Login failed or account text mismatch");
        log.info("Login successful");
    }

    @Test(priority = 4)
    public void verifyComputerText() throws IOException {
        System.out.println("Verifying computer text");
        boolean result = test.computerText();
        Assert.assertTrue(result, "Computer text is not displayed");
        log.info("Verified: 'Computers' text is displayed");
    }

    @Test(priority = 5)
    public void verifyElectronicsText() throws IOException {
        boolean result = test.electronicsText();
        Assert.assertTrue(result, "Electronics text is not displayed");
        log.info("Verified: 'Electronics' text is displayed");
    }

    @Test(priority = 6)
    public void verifyApparelText() throws IOException {
        boolean result = test.apparelText();
        Assert.assertTrue(result, "Apparel text is not displayed");
        log.info("Verified: 'Apparel' text is displayed");
    }

    @Test(priority = 7)
    public void logout() {
        login.logout();
        log.info("Logged out");
    }

    @AfterClass
    public void tearDown() {
        closeBrowser();
        log.info("Browser closed");
    }
}